Com o intuito de facilitar a leitura e avalia��o, os arquivos da primeira entrega foram agrupados e organizados no documento "Primeira_entrega.pdf"

Os mesmo encontram-se, tamb�m, separados e devidamente identificados na pasta Primeira_entrega